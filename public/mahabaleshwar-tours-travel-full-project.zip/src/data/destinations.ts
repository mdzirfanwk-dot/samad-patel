export interface DestinationItem {
  id: string;
  name: string;
  shortDesc: string;
  fullDesc: string;
  keyPoints: string[];
  image: string;
  elevation?: string;
  bestTime?: string;
}

export const destinationsData: DestinationItem[] = [
  {
    id: "mahabaleshwar",
    name: "Mahabaleshwar",
    shortDesc: "Hill station, viewpoints, forests and scenic drives.",
    fullDesc: "Perched at an elevation of 1,353 meters in the Sahyadri mountain range, Mahabaleshwar is the crowning jewel of Maharashtra's hill stations. Famed for its misty mornings, panoramic cliff lookouts like Arthur's Seat and Kate's Point, serene Venna Lake, and fresh strawberry farms, it provides an idyllic mountain retreat.",
    keyPoints: [
      "Arthur's Seat & Kate's Point",
      "Venna Lake boating",
      "Garden Ice Cream Restaurant & Mapro strawberry farms",
      "Lingmala Waterfall & Wilson Point"
    ],
    image: "/assets/aistudio/arthurs-seat.jpg",
    elevation: "1,353 m",
    bestTime: "Year-Round / Monsoon & Winter"
  },
  {
    id: "panchgani",
    name: "Panchgani",
    shortDesc: "Beautiful viewpoints, valleys and mountain landscapes.",
    fullDesc: "Named after the five majestic hills that surround it, Panchgani is renowned for the vast volcanic Table Land plateau, colonial architecture, and striking panoramas over the Krishna River valley and Dhom Dam waters. It is an essential stop for families and nature lovers.",
    keyPoints: [
      "Table Land volcanic plateau",
      "Sydney Point & Parsi Point",
      "Bhilar book village",
      "Fresh strawberry juice & fruit stalls"
    ],
    image: "/assets/aistudio/table-land.jpg",
    elevation: "1,293 m",
    bestTime: "Pleasant October to June"
  },
  {
    id: "pratapgad",
    name: "Pratapgad",
    shortDesc: "Historic fort and dramatic Western Ghats scenery.",
    fullDesc: "Situated approximately 24 km from Mahabaleshwar, Pratapgad stands as a legendary bastion of Maratha history. Towering over mountain passes with sheer drop-offs into the Konkan valley, the fort features formidable battlements, historic temples, and unforgettable 360-degree Sahyadri horizon views.",
    keyPoints: [
      "Historic 1656 mountain citadel",
      "Bhavani Mata Temple",
      "Breathtaking Western Ghats panoramas",
      "Scenic mountain pass descent"
    ],
    image: "/assets/aistudio/pratapgad-fort.jpg",
    elevation: "1,080 m",
    bestTime: "Post-monsoon & Winter"
  },
  {
    id: "tapola",
    name: "Tapola",
    shortDesc: "Lakeside landscapes and peaceful countryside.",
    fullDesc: "Often affectionately described as the 'Mini Kashmir of Maharashtra', Tapola lies nestled where the Koyna and Solshi rivers meet, forming the grand Shivsagar Lake reservoir. Surrounded by lush hills and quiet rural villages, it offers boating, water scooter rides, and peaceful nature walks away from the crowds.",
    keyPoints: [
      "Shivsagar Lake waters",
      "Boating, water scooters & kayaking",
      "Tranquil rural agro-tourism",
      "Dense Sahyadri forest tracks"
    ],
    image: "/assets/aistudio/shivasagar-tapola.jpg",
    elevation: "800 m",
    bestTime: "October to May"
  }
];
