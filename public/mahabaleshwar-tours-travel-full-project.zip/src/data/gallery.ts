export interface GalleryImage {
  id: string;
  title: string;
  spotName: string;
  category: "Mahabaleshwar" | "Panchgani" | "Pratapgad" | "Tapola" | "Scenic Roads" | "Local Experiences";
  caption: string;
  highlightBadge: string;
  tourCircuit: string;
  approxTime: string;
  distanceFromCenter: string;
  url: string;
}

export const galleryData: GalleryImage[] = [
  {
    id: "g-1",
    title: "Arthur's Seat (Queen of Points)",
    spotName: "Arthur's Seat Point",
    category: "Mahabaleshwar",
    caption: "Perched 1,340 m high offering a dramatic drop into the deep Savitri river valley and dense Sahyadri forests.",
    highlightBadge: "Top Viewpoint",
    tourCircuit: "Mahabaleshwar Local Sightseeing",
    approxTime: "1 - 1.5 Hours",
    distanceFromCenter: "13 km from market",
    url: "/assets/aistudio/arthurs-seat.jpg"
  },
  {
    id: "g-2",
    title: "Kate's Point & Needle Rock",
    spotName: "Kate's Point & Elephant's Head",
    category: "Mahabaleshwar",
    caption: "Breathtaking overlook of Balakwadi and Dhom reservoir with the natural elephant-trunk rock overhang.",
    highlightBadge: "Iconic Rock Overhang",
    tourCircuit: "Mahabaleshwar Local Sightseeing",
    approxTime: "45 - 60 Mins",
    distanceFromCenter: "7 km from town",
    url: "/assets/aistudio/kates-point.jpg"
  },
  {
    id: "g-3",
    title: "Needle Hole Rock (Elephant's Head)",
    spotName: "Needle Hole Vista",
    category: "Mahabaleshwar",
    caption: "A naturally weathered Sahyadri rock formation resembling an elephant's head and trunk pointing into the valley.",
    highlightBadge: "Natural Wonder",
    tourCircuit: "Mahabaleshwar Local Sightseeing",
    approxTime: "45 Mins",
    distanceFromCenter: "7 km from town",
    url: "/assets/aistudio/needle-hole-point.jpg"
  },
  {
    id: "g-4",
    title: "Table Land Plateau (Panchgani)",
    spotName: "Table Land",
    category: "Panchgani",
    caption: "Asia's second largest mountain plateau — a vast flat volcanic laterite rock expanse with 360-degree valley vistas.",
    highlightBadge: "Asia's 2nd Largest Plateau",
    tourCircuit: "Panchgani Day Tour",
    approxTime: "1.5 - 2 Hours",
    distanceFromCenter: "19 km from Mahabaleshwar",
    url: "/assets/aistudio/table-land.jpg"
  },
  {
    id: "g-5",
    title: "Sydney Point (Krishna Valley View)",
    spotName: "Sydney Point",
    category: "Panchgani",
    caption: "High cliff vantage point overlooking the winding Krishna River waters, Dhom Dam, and Wai valley.",
    highlightBadge: "Valley Panorama",
    tourCircuit: "Panchgani Day Tour",
    approxTime: "45 Mins",
    distanceFromCenter: "21 km from Mahabaleshwar",
    url: "/assets/aistudio/sydney-point.jpg"
  },
  {
    id: "g-6",
    title: "Historic Pratapgad Fort",
    spotName: "Pratapgad Bastion",
    category: "Pratapgad",
    caption: "Legendary 17th-century mountain citadel of Chhatrapati Shivaji Maharaj with ancient battlements and coastal views.",
    highlightBadge: "Historic Citadel",
    tourCircuit: "Pratapgad Fort Heritage Tour",
    approxTime: "2 - 3 Hours",
    distanceFromCenter: "22 km from Mahabaleshwar",
    url: "/assets/aistudio/pratapgad-fort.jpg"
  },
  {
    id: "g-7",
    title: "Pratapgad Ramparts & Bhavani Temple",
    spotName: "Pratapgad Heritage",
    category: "Pratapgad",
    caption: "Dramatic mountain bastion surrounded by steep escarpments, historic watchtowers, and the revered Bhavani Mata Temple.",
    highlightBadge: "Maratha Heritage",
    tourCircuit: "Pratapgad Fort Heritage Tour",
    approxTime: "2 Hours",
    distanceFromCenter: "22 km from Mahabaleshwar",
    url: "/assets/aistudio/pratapgad-valour.jpg"
  },
  {
    id: "g-8",
    title: "Shivsagar Lake Waterfront (Tapola)",
    spotName: "Tapola Shivsagar Lake",
    category: "Tapola",
    caption: "Tranquil expanse of the Koyna reservoir, fondly celebrated as the 'Mini Kashmir of Maharashtra' with speedboat rides.",
    highlightBadge: "Mini Kashmir Waters",
    tourCircuit: "Tapola Lakeside Tour",
    approxTime: "Half / Full Day",
    distanceFromCenter: "28 km from Mahabaleshwar",
    url: "/assets/aistudio/shivasagar-tapola.jpg"
  },
  {
    id: "g-9",
    title: "Venna Lake & Lakeside Boating",
    spotName: "Venna Lake",
    category: "Local Experiences",
    caption: "The sparkling centerpiece of Mahabaleshwar, surrounded by tall pine trees, pedal boats, rowboats, and evening food stalls.",
    highlightBadge: "Lakeside Boating",
    tourCircuit: "Mahabaleshwar Local Sightseeing",
    approxTime: "1 - 2 Hours",
    distanceFromCenter: "2.5 km from market",
    url: "/assets/aistudio/venna-lake.jpg"
  },
  {
    id: "g-10",
    title: "Fresh Strawberry Farms & Orchards",
    spotName: "Strawberry Farm Experience",
    category: "Local Experiences",
    caption: "Step right into lush strawberry gardens to see ripe red Mahabaleshwar strawberries cultivated in the cool mountain climate.",
    highlightBadge: "Agro Tourism",
    tourCircuit: "Mahabaleshwar Local Sightseeing",
    approxTime: "45 - 60 Mins",
    distanceFromCenter: "Around Mahabaleshwar",
    url: "/assets/aistudio/strawberry-farm.jpg"
  },
  {
    id: "g-11",
    title: "Garden Ice Cream Restaurant",
    spotName: "Garden Ice Cream Restaurant",
    category: "Local Experiences",
    caption: "The must-visit Mahabaleshwar culinary destination famous for fresh strawberry desserts, farm ice creams & fruit shakes.",
    highlightBadge: "Must-Visit Food Spot",
    tourCircuit: "Mahabaleshwar Local Sightseeing",
    approxTime: "45 Mins",
    distanceFromCenter: "Near Nakinda / Town",
    url: "/assets/aistudio/garden-icecream-restaurant.jpg"
  },
  {
    id: "g-12",
    title: "Signature Strawberry Cream Dessert",
    spotName: "Fresh Strawberry with Cream",
    category: "Local Experiences",
    caption: "A chilled bowl of fresh hand-picked red strawberries smothered in rich homemade fresh cream and strawberry scoop.",
    highlightBadge: "Local Speciality",
    tourCircuit: "Mahabaleshwar Local Sightseeing",
    approxTime: "Treat Time",
    distanceFromCenter: "Local cafes & farm outlets",
    url: "/assets/aistudio/strawberry-icecream-restaurant.jpg"
  },
  {
    id: "g-13",
    title: "Winding Pasarni & Western Ghats Roads",
    spotName: "Scenic Ghat Passes",
    category: "Scenic Roads",
    caption: "Smooth, scenic mountain drives through lush Sahyadri hills, mist-shrouded hairpins, and forest canopies.",
    highlightBadge: "Scenic Drive",
    tourCircuit: "All Tours & Transfers",
    approxTime: "En-Route",
    distanceFromCenter: "Connecting routes",
    url: "/assets/aistudio/western-ghats-road.jpg"
  },
  {
    id: "g-14",
    title: "Sunset over Dhom Dam & Valleys",
    spotName: "Dhom Lake Sunset",
    category: "Mahabaleshwar",
    caption: "Golden evening light casting a warm Sahyadri glow over the calm waters of Dhom reservoir and surrounding peaks.",
    highlightBadge: "Golden Hour Vista",
    tourCircuit: "Panchgani / Mahabaleshwar Tour",
    approxTime: "Sunset 5:30 - 6:30 PM",
    distanceFromCenter: "Wai / Panchgani foothills",
    url: "/assets/aistudio/sunset-dhom-lake.jpg"
  }
];
