import React from "react";
import { About } from "../components/About";
import { WhyChooseUs } from "../components/WhyChooseUs";
import { MapSection } from "../components/MapSection";
import { ArrowLeft, Shield } from "lucide-react";
import { FinalCTA } from "../components/FinalCTA";

interface AboutPageProps {
  onNavigate: (path: string) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate }) => {
  return (
    <div className="bg-[#F7F5F0] min-h-screen">
      <div className="bg-[#071C14] text-white border-b border-[#12372A] py-12 md:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Website Breadcrumb */}
          <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs text-white/70 mb-5">
            <a
              href="/"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("/");
              }}
              className="hover:text-[#D4A853] transition-colors"
            >
              Home
            </a>
            <span className="text-white/40">/</span>
            <span className="text-[#D4A853] font-medium">About Us</span>
          </nav>

          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#12372A] border border-[#D4A853]/30 text-[#D4A853] text-xs font-semibold uppercase tracking-wider mb-3">
            <Shield className="w-3 h-3" />
            <span>Company Profile</span>
          </div>

          <h1 className="font-serif text-3xl sm:text-5xl font-bold text-white tracking-tight">
            About Mahabaleshwar Wala Tours &amp; Travels
          </h1>
          <p className="mt-3 text-base text-white/80 max-w-2xl leading-relaxed">
            Your trusted local travel partner in Mahabaleshwar, operating opposite Brightland Resort in Nakinda.
          </p>
        </div>
      </div>

      <About />
      <WhyChooseUs />
      <MapSection />
      <FinalCTA />
    </div>
  );
};
