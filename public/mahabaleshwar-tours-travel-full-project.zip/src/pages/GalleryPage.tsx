import React from "react";
import { MahabaleshwarGallery } from "../components/MahabaleshwarGallery";
import { BookingWidget } from "../components/BookingWidget";
import { Camera, Sparkles, MapPin, CheckCircle2 } from "lucide-react";
import { FinalCTA } from "../components/FinalCTA";

interface GalleryPageProps {
  onNavigate: (path: string) => void;
  onOpenBookingModal?: (destinationName?: string) => void;
}

export const GalleryPage: React.FC<GalleryPageProps> = ({
  onNavigate,
  onOpenBookingModal
}) => {
  return (
    <div className="bg-[#F7F5F0] min-h-screen">
      {/* Page Header */}
      <div className="bg-[#071C14] text-white border-b border-[#12372A] py-12 md:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Website Breadcrumbs */}
          <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs text-white/70 mb-5">
            <a
              href="/"
              onClick={(e) => {
                e.preventDefault();
                onNavigate("/");
              }}
              className="hover:text-[#D4A853] transition-colors"
            >
              Home
            </a>
            <span className="text-white/40">/</span>
            <span className="text-[#D4A853] font-medium">Mahabaleshwar Gallery</span>
          </nav>

          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#12372A] border border-[#D4A853]/30 text-[#D4A853] text-xs font-semibold uppercase tracking-wider mb-3">
            <Camera className="w-3 h-3" />
            <span>Visual Destination Showcase</span>
          </div>

          <h1 className="font-serif text-3xl sm:text-5xl font-bold text-white tracking-tight">
            Mahabaleshwar Gallery
          </h1>
          <p className="mt-3 text-base text-white/80 max-w-2xl leading-relaxed">
            Scroll through high-resolution authentic photographs of Mahabaleshwar, Panchgani, Pratapgad, and Tapola. Explore top cliff viewpoints, tranquil lakes, historic fortresses, and strawberry plantations before booking your journey.
          </p>

          {/* Quick Highlight Pills */}
          <div className="mt-6 flex flex-wrap items-center gap-4 text-xs text-white/80">
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-[#25D366]" />
              <span>14 Verified Tourist Spots</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-[#25D366]" />
              <span>Scroll &amp; Inspect Before Booking</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-[#25D366]" />
              <span>Instant Taxi Quotation via WhatsApp</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Booking Bar Floating Over Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6">
        <BookingWidget />
      </div>

      {/* The Mahabaleshwar Gallery Component */}
      <MahabaleshwarGallery onOpenBookingModal={onOpenBookingModal} />

      {/* Final Call to Action */}
      <FinalCTA />
    </div>
  );
};
