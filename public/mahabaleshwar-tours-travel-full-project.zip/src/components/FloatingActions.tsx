import React from "react";
import { Phone, MessageCircle, Calendar } from "lucide-react";
import { businessConfig } from "../data/businessConfig";
import { buildGeneralWhatsAppUrl } from "../utils/whatsapp";

interface FloatingActionsProps {
  onOpenBooking?: () => void;
}

export const FloatingActions: React.FC<FloatingActionsProps> = ({ onOpenBooking }) => {
  const whatsappUrl = buildGeneralWhatsAppUrl();

  return (
    <aside aria-label="Quick contact" className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-2.5 pointer-events-none">
      {/* Desktop Floating Action Buttons */}
      <div className="hidden md:flex items-center gap-3 pointer-events-auto">
        {/* Call Button */}
        <a
          href={`tel:${businessConfig.phoneRaw}`}
          className="flex items-center gap-2.5 bg-[#12372A] hover:bg-[#071C14] text-white py-2.5 px-4 rounded-full border border-[#D4A853]/40 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-0.5 active:scale-95 group"
          title={`Call ${businessConfig.phone}`}
          aria-label="Call Mahabaleshwar wala Tours and Travel"
        >
          <div className="w-7 h-7 rounded-full bg-[#0B2118] flex items-center justify-center text-[#D4A853]">
            <Phone className="w-3.5 h-3.5" />
          </div>
          <div className="text-left pr-1">
            <span className="text-[10px] text-[#D4A853] font-semibold uppercase tracking-wider block leading-none">
              Direct Desk
            </span>
            <span className="text-xs font-bold text-white leading-tight">
              {businessConfig.phone}
            </span>
          </div>
        </a>

        {/* WhatsApp Button */}
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2.5 bg-[#25D366] hover:bg-[#20b859] text-white py-2.5 px-4.5 rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-0.5 active:scale-95 group"
          title="Chat with us on WhatsApp"
          aria-label="Chat on WhatsApp with Mahabaleshwar wala Tours and Travel"
        >
          <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center">
            <MessageCircle className="w-4 h-4 text-white" />
          </div>
          <div className="text-left pr-1">
            <span className="text-[10px] text-white/90 font-semibold uppercase tracking-wider block leading-none">
              Instant Reply
            </span>
            <span className="text-xs font-bold text-white leading-tight">
              WhatsApp Us
            </span>
          </div>
        </a>
      </div>

      {/* Mobile Responsive Floating Contact Widget (Standard Website Pattern) */}
      <div className="md:hidden flex items-center gap-2 pointer-events-auto">
        <a
          href={`tel:${businessConfig.phoneRaw}`}
          className="w-12 h-12 rounded-full bg-[#071C14] text-[#D4A853] border border-[#D4A853]/40 flex items-center justify-center shadow-2xl active:scale-90 transition-transform"
          aria-label="Call Mahabaleshwar wala Tours and Travel"
          title="Call Now"
        >
          <Phone className="w-5 h-5" />
        </a>

        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 bg-[#25D366] text-white px-4 py-3 rounded-full shadow-2xl active:scale-90 transition-transform font-bold text-xs"
          aria-label="WhatsApp Mahabaleshwar wala Tours and Travel"
          title="Chat on WhatsApp"
        >
          <MessageCircle className="w-5 h-5 text-white" />
          <span>Chat 24/7</span>
        </a>
      </div>
    </aside>
  );
};
