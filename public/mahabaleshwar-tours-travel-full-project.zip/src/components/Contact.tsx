import React, { useState } from "react";
import { Phone, MessageCircle, MapPin, Clock, Send, ShieldCheck } from "lucide-react";
import { businessConfig } from "../data/businessConfig";
import { buildWhatsAppUrl, buildGeneralWhatsAppUrl } from "../utils/whatsapp";

export const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: "",
    pickup: "",
    destination: "Mahabaleshwar Sightseeing",
    date: "",
    passengers: "2",
    notes: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const message = `Hello Mahabaleshwar Wala Tours & Travel,
I would like to enquire about a trip.
Name: ${formData.name || "Traveller"}
Pickup: ${formData.pickup || "Mahabaleshwar / Hotel"}
Destination: ${formData.destination}
Travel Date: ${formData.date || "To be confirmed"}
Passengers: ${formData.passengers}
${formData.notes ? `Special Notes: ${formData.notes}\n` : ""}Please share vehicle options and the best available price.
Thank you.`;

    window.open(buildWhatsAppUrl(message), "_blank", "noopener,noreferrer");
  };

  return (
    <section id="contact" className="py-16 sm:py-24 bg-[#F7F5F0]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Left: Verified Business Info */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#12372A]/10 text-[#12372A] text-xs font-bold uppercase tracking-wider mb-3">
                <MapPin className="w-3.5 h-3.5 text-[#D4A853]" />
                <span>Direct Local Contact</span>
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#071C14] tracking-tight">
                Let’s Plan Your Journey
              </h2>
              <p className="mt-3 text-sm sm:text-base text-[#6B7280] leading-relaxed">
                Connect with our local desk anytime. We assist with itinerary planning, vehicle recommendations, and local travel tips.
              </p>
            </div>

            {/* Direct Contact Cards */}
            <div className="space-y-3 pt-2">
              {/* Phone Card */}
              <div className="bg-white rounded-2xl p-5 border border-[#12372A]/10 shadow-sm flex items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div className="w-11 h-11 rounded-xl bg-[#12372A] text-[#D4A853] flex items-center justify-center shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-[#6B7280] tracking-wider block">
                      Phone Call
                    </span>
                    <a
                      href={`tel:${businessConfig.phoneRaw}`}
                      className="text-base sm:text-lg font-bold text-[#071C14] hover:text-[#D4A853] transition-colors"
                    >
                      {businessConfig.phone}
                    </a>
                  </div>
                </div>

                <a
                  href={`tel:${businessConfig.phoneRaw}`}
                  className="bg-[#12372A] hover:bg-[#071C14] text-white text-xs font-semibold py-2 px-4 rounded-xl transition-colors shrink-0"
                >
                  Call Now
                </a>
              </div>

              {/* WhatsApp Card */}
              <div className="bg-white rounded-2xl p-5 border border-[#12372A]/10 shadow-sm flex items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div className="w-11 h-11 rounded-xl bg-[#25D366] text-white flex items-center justify-center shrink-0">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-[#6B7280] tracking-wider block">
                      WhatsApp Chat
                    </span>
                    <div className="text-sm font-semibold text-[#071C14]">
                      Chat with us on WhatsApp
                    </div>
                  </div>
                </div>

                <a
                  href={buildGeneralWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-[#25D366] hover:bg-[#20b859] text-white text-xs font-bold py-2 px-4 rounded-xl shadow-sm transition-all shrink-0"
                >
                  WhatsApp Us
                </a>
              </div>

              {/* Address Card */}
              <div className="bg-white rounded-2xl p-5 border border-[#12372A]/10 shadow-sm flex items-start gap-3.5">
                <div className="w-11 h-11 rounded-xl bg-[#F7F5F0] text-[#12372A] flex items-center justify-center shrink-0 mt-0.5 border border-[#12372A]/10">
                  <MapPin className="w-5 h-5 text-[#D4A853]" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#6B7280] tracking-wider block">
                    Verified Address
                  </span>
                  <p className="text-xs sm:text-sm font-medium text-[#071C14] mt-0.5 leading-relaxed">
                    {businessConfig.address}
                  </p>
                </div>
              </div>

              {/* Hours Card */}
              <div className="bg-white rounded-2xl p-5 border border-[#12372A]/10 shadow-sm flex items-center gap-3.5">
                <div className="w-11 h-11 rounded-xl bg-[#F7F5F0] text-[#25D366] flex items-center justify-center shrink-0 border border-[#12372A]/10">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#6B7280] tracking-wider block">
                    Operating Hours
                  </span>
                  <div className="text-sm font-bold text-[#25D366] flex items-center gap-2 mt-0.5">
                    <span className="w-2 h-2 rounded-full bg-[#25D366] animate-pulse" />
                    <span>{businessConfig.availability}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Quick Travel Enquiry Card */}
          <div className="lg:col-span-7">
            <div className="bg-[#071C14] text-[#F7F5F0] rounded-3xl border border-[#D4A853]/30 p-7 sm:p-10 shadow-2xl space-y-6">
              <div className="space-y-1 pb-4 border-b border-[#12372A]">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#D4A853]">
                  <ShieldCheck className="w-4 h-4 text-[#25D366]" />
                  <span>Direct Quote via WhatsApp</span>
                </div>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white">
                  Send a Travel Request
                </h3>
                <p className="text-xs text-white/70">
                  Fill in your details below and hit send to generate an instant WhatsApp message with our team.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs uppercase tracking-wider font-semibold text-[#D4A853] mb-1.5">
                      Your Name
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Rahul Sharma"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-[#0B2118] border border-[#12372A] rounded-xl text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#D4A853]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-wider font-semibold text-[#D4A853] mb-1.5">
                      Pickup Location
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Resort / Hotel in Mahabaleshwar"
                      value={formData.pickup}
                      onChange={(e) => setFormData({ ...formData, pickup: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-[#0B2118] border border-[#12372A] rounded-xl text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#D4A853]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-wider font-semibold text-[#D4A853] mb-1.5">
                      Destination / Tour Circuit
                    </label>
                    <select
                      value={formData.destination}
                      onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-[#0B2118] border border-[#12372A] rounded-xl text-xs text-white focus:outline-none focus:border-[#D4A853] cursor-pointer"
                    >
                      <option value="Mahabaleshwar Sightseeing" className="bg-[#071C14]">Mahabaleshwar Sightseeing</option>
                      <option value="Panchgani Day Tour" className="bg-[#071C14]">Panchgani Day Tour</option>
                      <option value="Pratapgad Fort Trip" className="bg-[#071C14]">Pratapgad Fort Trip</option>
                      <option value="Tapola Lakeside Excursion" className="bg-[#071C14]">Tapola Lakeside Excursion</option>
                      <option value="Airport Transfer (Pune/Mumbai)" className="bg-[#071C14]">Airport Transfer (Pune/Mumbai)</option>
                      <option value="Outstation Journey" className="bg-[#071C14]">Outstation Journey</option>
                      <option value="Custom Multi-day Tour" className="bg-[#071C14]">Custom Multi-day Tour</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-wider font-semibold text-[#D4A853] mb-1.5">
                      Travel Date
                    </label>
                    <input
                      type="date"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      min={new Date().toISOString().split("T")[0]}
                      className="w-full px-3.5 py-2.5 bg-[#0B2118] border border-[#12372A] rounded-xl text-xs text-white focus:outline-none focus:border-[#D4A853] cursor-pointer"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs uppercase tracking-wider font-semibold text-[#D4A853] mb-1.5">
                      Number of Passengers
                    </label>
                    <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                      {["1-2", "3-4", "5", "6", "7", "8+"].map((cnt) => (
                        <button
                          key={cnt}
                          type="button"
                          onClick={() => setFormData({ ...formData, passengers: cnt })}
                          className={`py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                            formData.passengers === cnt
                              ? "bg-[#D4A853] text-[#071C14] border-[#D4A853]"
                              : "bg-[#0B2118] text-white/80 border-[#12372A] hover:border-white/30"
                          }`}
                        >
                          {cnt}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs uppercase tracking-wider font-semibold text-[#D4A853] mb-1.5">
                      Additional Requirements / Hotel Name
                    </label>
                    <textarea
                      rows={2}
                      placeholder="Any specific viewpoints or questions you'd like to ask..."
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-[#0B2118] border border-[#12372A] rounded-xl text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#D4A853]"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center gap-2.5 bg-[#25D366] hover:bg-[#20b859] text-white font-bold text-xs uppercase tracking-wider py-3.5 px-6 rounded-xl shadow-lg hover:shadow-xl transition-all cursor-pointer transform active:scale-95"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Send Enquiry via WhatsApp</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
