import React from "react";
import { MapPin, Phone, Clock, MessageCircle } from "lucide-react";
import { businessConfig } from "../data/businessConfig";
import { buildGeneralWhatsAppUrl } from "../utils/whatsapp";
import { BusinessInfoCard } from "./BusinessInfoCard";

export const About: React.FC = () => {
  return (
    <section id="about" className="py-16 sm:py-24 bg-[#F7F5F0]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Authentic Brand Narrative */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#12372A]/10 text-[#12372A] text-xs font-bold uppercase tracking-wider">
              <span>Local Roots &amp; Service</span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#071C14] tracking-tight">
              Your Mahabaleshwar Travel Partner
            </h2>

            <div className="space-y-4 text-base text-[#1C1C1C]/80 leading-relaxed font-normal">
              <p>
                Mahabaleshwar wala Tours and Travel is a local travel business based in Mahabaleshwar, Maharashtra, helping travellers plan convenient journeys around the region. Whether you’re exploring Mahabaleshwar, visiting Panchgani, heading towards Pratapgad or planning a customised trip, the goal is to make booking simple and travel comfortable.
              </p>

              <div className="p-4 rounded-xl bg-white border border-[#12372A]/10 shadow-sm flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#D4A853] shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-[#071C14] text-sm">
                    Verified Physical Location
                  </div>
                  <div className="text-xs text-[#6B7280] mt-0.5">
                    Located opposite Brightland Resort, Nakinda, Mahabaleshwar, Maharashtra 412806, India.
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <a
                href={buildGeneralWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-[#D4A853] hover:bg-[#C29541] text-[#071C14] font-bold text-xs uppercase tracking-wider py-3 px-6 rounded-xl shadow-md hover:shadow-lg transition-all"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Chat on WhatsApp</span>
              </a>

              <a
                href={`tel:${businessConfig.phoneRaw}`}
                className="inline-flex items-center gap-2 bg-white hover:bg-[#F7F5F0] text-[#071C14] border border-[#12372A]/20 font-semibold text-xs py-3 px-5 rounded-xl transition-colors"
              >
                <Phone className="w-4 h-4 text-[#D4A853]" />
                <span>Call {businessConfig.phone}</span>
              </a>
            </div>
          </div>

          {/* Right Column: Business Info Card & Location Highlight */}
          <div className="lg:col-span-5 space-y-6">
            <BusinessInfoCard theme="dark" />

            <div className="bg-[#12372A] rounded-2xl p-5 text-white flex items-center justify-between gap-4 border border-[#D4A853]/25">
              <div className="flex items-center gap-3">
                <Clock className="w-6 h-6 text-[#25D366] shrink-0" />
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wider text-[#D4A853]">
                    Google Business Listing Status
                  </div>
                  <div className="text-sm font-bold mt-0.5">
                    Open 24 Hours
                  </div>
                </div>
              </div>
              <span className="text-[11px] bg-[#071C14] text-white/80 px-2.5 py-1 rounded-md border border-white/10">
                Active
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
