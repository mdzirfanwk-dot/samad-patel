import React, { useState } from "react";
import { ArrowRight, MapPin, Sparkles, MessageCircle, X } from "lucide-react";
import { destinationsData, DestinationItem } from "../data/destinations";
import { buildDestinationEnquiryUrl } from "../utils/whatsapp";
import { Image } from "./Image";

export const Destinations: React.FC = () => {
  const [activeDestination, setActiveDestination] = useState<DestinationItem | null>(null);

  const handleEnquire = (dest: DestinationItem) => {
    window.open(buildDestinationEnquiryUrl(dest.name), "_blank", "noopener,noreferrer");
  };

  return (
    <section id="destinations" className="py-16 sm:py-24 bg-[#F7F5F0]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#12372A]/10 text-[#12372A] text-xs font-bold uppercase tracking-wider mb-3">
            <MapPin className="w-3.5 h-3.5 text-[#D4A853]" />
            <span>Signature Regions</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#071C14] tracking-tight">
            Discover the Best of Mahabaleshwar
          </h2>
          <p className="mt-3 text-base text-[#6B7280] leading-relaxed">
            From the high cloud-swept plateaus of Panchgani to the waters of Tapola and the ramparts of Pratapgad, experience the diverse charm of the Western Ghats.
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {destinationsData.map((dest) => (
            <div
              key={dest.id}
              className="group bg-white rounded-2xl border border-[#12372A]/10 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden hover:-translate-y-1"
            >
              <div className="relative h-56 overflow-hidden">
                <Image
                  src={dest.image}
                  alt={dest.name}
                  containerClassName="w-full h-full absolute inset-0"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#071C14] via-[#071C14]/30 to-transparent z-10 pointer-events-none" />

                {dest.elevation && (
                  <span className="absolute top-3 left-3 bg-[#071C14]/80 backdrop-blur-md text-white/90 text-[10px] font-medium px-2.5 py-1 rounded-md border border-white/10">
                    {dest.elevation}
                  </span>
                )}

                <div className="absolute bottom-3 left-4 right-4">
                  <h3 className="font-serif text-2xl font-bold text-white group-hover:text-[#D4A853] transition-colors">
                    {dest.name}
                  </h3>
                </div>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <p className="text-xs sm:text-sm text-[#6B7280] leading-relaxed">
                  {dest.shortDesc}
                </p>

                <div className="pt-3 border-t border-[#12372A]/5 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setActiveDestination(dest)}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#12372A] hover:text-[#D4A853] group-hover:translate-x-0.5 transition-all cursor-pointer"
                  >
                    <span>Explore Destination</span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#D4A853]" />
                  </button>

                  <button
                    type="button"
                    onClick={() => handleEnquire(dest)}
                    className="p-2 rounded-lg bg-[#25D366]/10 text-[#25D366] hover:bg-[#25D366] hover:text-white transition-colors cursor-pointer"
                    title={`Enquire trip to ${dest.name}`}
                  >
                    <MessageCircle className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Destination Modal */}
      {activeDestination && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in"
          onClick={() => setActiveDestination(null)}
        >
          <div
            className="bg-[#071C14] text-[#F7F5F0] border border-[#D4A853]/40 rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 sm:p-7 shadow-2xl space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4 pb-3 border-b border-[#12372A]">
              <div>
                <span className="text-[11px] uppercase tracking-wider text-[#D4A853] font-semibold">
                  Destination Profile
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white mt-1">
                  {activeDestination.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveDestination(null)}
                className="p-2 rounded-xl bg-[#12372A] text-white/70 hover:text-white hover:bg-[#12372A]/80 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="relative h-44 rounded-xl overflow-hidden">
                <Image
                  src={activeDestination.image}
                  alt={activeDestination.name}
                  containerClassName="w-full h-full absolute inset-0"
                  className="w-full h-full object-cover"
                />
              </div>

              <p className="text-xs sm:text-sm text-white/85 leading-relaxed">
                {activeDestination.fullDesc}
              </p>

              <div>
                <div className="text-xs uppercase tracking-wider font-semibold text-[#D4A853] mb-2">
                  Key Sights &amp; Attractions:
                </div>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-white/80">
                  {activeDestination.keyPoints.map((point, idx) => (
                    <li key={idx} className="flex items-center gap-2 bg-[#12372A]/50 px-2.5 py-1.5 rounded-lg border border-white/5">
                      <Sparkles className="w-3 h-3 text-[#D4A853] shrink-0" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-2 flex gap-3">
              <button
                type="button"
                onClick={() => {
                  handleEnquire(activeDestination);
                  setActiveDestination(null);
                }}
                className="w-full inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#20b859] text-white py-3 px-6 rounded-xl font-bold text-xs shadow-lg transition-all"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Enquire {activeDestination.name} Tour on WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
