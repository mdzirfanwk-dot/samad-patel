import React from "react";
import { Star, MessageSquare, Clock, MapPin } from "lucide-react";

export const TrustBar: React.FC = () => {
  const trustMetrics = [
    {
      icon: Star,
      value: "5.0",
      label: "Google Rating",
      sublabel: "Verified ★★★★★ score",
      iconColor: "text-[#D4A853]"
    },
    {
      icon: MessageSquare,
      value: "13",
      label: "Google Reviews",
      sublabel: "Independent traveller feedback",
      iconColor: "text-[#D4A853]"
    },
    {
      icon: Clock,
      value: "24/7",
      label: "Travel Assistance",
      sublabel: "Google-listed round-the-clock",
      iconColor: "text-[#25D366]"
    },
    {
      icon: MapPin,
      value: "Local",
      label: "Mahabaleshwar Travel",
      sublabel: "Opposite Brightland, Nakinda",
      iconColor: "text-[#D4A853]"
    }
  ];

  return (
    <div className="bg-[#0B2118] border-y border-[#12372A] py-6 sm:py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 divide-y sm:divide-y-0 sm:divide-x divide-[#12372A]">
          {trustMetrics.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className={`flex items-center gap-3.5 ${
                  idx > 0 ? "pt-4 sm:pt-0 sm:pl-6" : ""
                }`}
              >
                <div className="w-11 h-11 rounded-xl bg-[#12372A] border border-[#D4A853]/20 flex items-center justify-center shrink-0">
                  <Icon className={`w-5 h-5 ${item.iconColor}`} />
                </div>
                <div>
                  <div className="flex items-baseline gap-1.5">
                    <span className="font-serif text-xl sm:text-2xl font-bold text-[#F7F5F0]">
                      {item.value}
                    </span>
                  </div>
                  <div className="text-xs font-semibold text-[#D4A853] tracking-wide">
                    {item.label}
                  </div>
                  <div className="text-[11px] text-white/50 hidden sm:block">
                    {item.sublabel}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
