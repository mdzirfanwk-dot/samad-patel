import React, { useState } from "react";
import { Clock, Tag, CheckCircle2, MessageCircle, ArrowRight, X, Sparkles, MapPin } from "lucide-react";
import { toursData, TourPackage } from "../data/tours";
import { buildTourEnquiryUrl } from "../utils/whatsapp";
import { Image } from "./Image";

export const Tours: React.FC = () => {
  const [selectedTour, setSelectedTour] = useState<TourPackage | null>(null);

  const handleEnquire = (tour: TourPackage) => {
    const url = buildTourEnquiryUrl(tour.name);
    window.open(url, "_blank", "noopener,noreferrer");
  };

  return (
    <section id="tours" className="py-16 sm:py-24 bg-[#0B2118] text-[#F7F5F0]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#12372A] border border-[#D4A853]/30 text-[#D4A853] text-xs font-semibold uppercase tracking-wider mb-3">
              <Sparkles className="w-3 h-3" />
              <span>Curated Sightseeing</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#F7F5F0] tracking-tight">
              Popular Tour Packages
            </h2>
            <p className="mt-3 text-base text-[#F7F5F0]/80 leading-relaxed">
              Experience the best of the Sahyadri hills with our suggested tour circuits. All itineraries are fully customizable.
            </p>
          </div>

          <div className="text-left md:text-right">
            <span className="text-xs text-[#D4A853] font-medium block">
              *Transparent Pricing on Request
            </span>
            <span className="text-[11px] text-white/50 block mt-0.5">
              No hidden driver charges or advance booking fees
            </span>
          </div>
        </div>

        {/* Tour Package Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {toursData.map((tour) => (
            <div
              key={tour.id}
              className="bg-[#071C14] rounded-2xl border border-[#12372A] hover:border-[#D4A853]/40 overflow-hidden shadow-xl transition-all duration-300 flex flex-col group"
            >
              {/* Image Container */}
              <div className="relative h-64 sm:h-72 overflow-hidden">
                <Image
                  src={tour.image}
                  alt={tour.name}
                  containerClassName="w-full h-full absolute inset-0"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#071C14] via-[#071C14]/40 to-transparent z-10 pointer-events-none" />

                {/* Badge */}
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-[#12372A]/90 backdrop-blur-md text-[#D4A853] text-xs font-semibold rounded-lg border border-[#D4A853]/30 shadow-md">
                    {tour.tag}
                  </span>
                </div>

                {/* Duration & Starting Price floating strip */}
                <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-1.5 bg-[#071C14]/85 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 text-white/90">
                    <Clock className="w-3.5 h-3.5 text-[#D4A853]" />
                    <span>{tour.duration}</span>
                  </div>

                  <div className="flex items-center gap-1.5 bg-[#12372A]/95 backdrop-blur-md px-3 py-1.5 rounded-lg border border-[#D4A853]/40 text-[#D4A853] font-semibold">
                    <Tag className="w-3.5 h-3.5" />
                    <span>{tour.priceDisplay}</span>
                  </div>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between space-y-5">
                <div>
                  <div className="text-xs uppercase tracking-widest font-semibold text-[#D4A853] mb-1">
                    {tour.subtitle}
                  </div>
                  <h3 className="font-serif text-2xl font-bold text-white group-hover:text-[#D4A853] transition-colors">
                    {tour.name}
                  </h3>
                  <p className="mt-2 text-sm text-[#F7F5F0]/80 leading-relaxed">
                    {tour.description}
                  </p>

                  {/* Highlights */}
                  <div className="mt-4 pt-4 border-t border-[#12372A] space-y-2">
                    <div className="text-[11px] uppercase tracking-wider font-semibold text-white/50">
                      Key Highlights:
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {tour.highlights.map((h, i) => (
                        <div key={i} className="flex items-center gap-2 text-xs text-white/85">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#D4A853] shrink-0" />
                          <span className="truncate">{h}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="pt-4 border-t border-[#12372A] flex flex-col sm:flex-row items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setSelectedTour(tour)}
                    className="w-full sm:w-auto flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl border border-white/20 hover:border-[#D4A853] text-xs font-semibold text-white/90 hover:text-white transition-colors cursor-pointer"
                  >
                    <span>View Itinerary</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => handleEnquire(tour)}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#20b859] text-white text-xs font-bold py-2.5 px-5 rounded-xl shadow-md hover:shadow-lg transition-all cursor-pointer transform active:scale-95 shrink-0"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Enquire on WhatsApp</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Itinerary Modal */}
      {selectedTour && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in"
          onClick={() => setSelectedTour(null)}
        >
          <div
            className="bg-[#071C14] text-[#F7F5F0] border border-[#D4A853]/40 rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 shadow-2xl space-y-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-[#12372A]">
              <div>
                <span className="text-xs text-[#D4A853] font-semibold tracking-wider uppercase">
                  Suggested Itinerary
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white mt-1">
                  {selectedTour.name}
                </h3>
                <p className="text-xs text-white/70 mt-1">
                  Duration: {selectedTour.duration} • {selectedTour.priceDisplay}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedTour(null)}
                className="p-2 rounded-xl bg-[#12372A] text-white/70 hover:text-white hover:bg-[#12372A]/80 transition-colors"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <p className="text-sm text-white/80 leading-relaxed">
                {selectedTour.description}
              </p>

              <div>
                <h4 className="text-xs uppercase tracking-wider font-semibold text-[#D4A853] mb-3">
                  Places Covered in this Circuit:
                </h4>
                <ol className="space-y-2.5 relative border-l border-[#D4A853]/30 ml-2 pl-4">
                  {selectedTour.suggestedItinerary.map((stop, index) => (
                    <li key={index} className="relative">
                      <span className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-[#D4A853] border-2 border-[#071C14]" />
                      <div className="text-sm font-medium text-white">{stop}</div>
                    </li>
                  ))}
                </ol>
              </div>

              <div className="p-3.5 rounded-xl bg-[#12372A]/60 border border-[#D4A853]/20 text-xs text-white/80 flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#D4A853] shrink-0 mt-0.5" />
                <span>
                  All stops can be tailored to your hotel pickup location and family pace. Enquire on WhatsApp to confirm vehicle types and schedule.
                </span>
              </div>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  handleEnquire(selectedTour);
                  setSelectedTour(null);
                }}
                className="w-full inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#20b859] text-white py-3 px-6 rounded-xl font-bold text-xs shadow-lg transition-all"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Enquire This Package on WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
