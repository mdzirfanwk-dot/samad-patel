import React, { useState, useEffect } from "react";
import { Menu, X, Phone, MessageCircle, MapPin } from "lucide-react";
import { businessConfig } from "../data/businessConfig";
import { buildGeneralWhatsAppUrl } from "../utils/whatsapp";

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, onNavigate }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { label: "Home", path: "/" },
    { label: "Tours", path: "/tours" },
    { label: "Destinations", path: "/destinations" },
    { label: "Gallery", path: "/gallery" },
    { label: "Services", path: "/services" },
    { label: "Fleet", path: "/fleet" },
    { label: "Reviews", path: "/reviews" },
    { label: "About", path: "/about" },
    { label: "Contact", path: "/contact" }
  ];

  const handleLinkClick = (path: string, e: React.MouseEvent) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    onNavigate(path);
  };

  return (
    <header
      className={`sticky top-0 z-40 transition-all duration-300 ${
        isScrolled
          ? "bg-[#071C14]/95 backdrop-blur-md shadow-lg border-b border-[#D4A853]/20 py-2.5"
          : "bg-[#0B2118] border-b border-[#12372A] py-3.5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand Logo & Name */}
        <a
          href="/"
          onClick={(e) => handleLinkClick("/", e)}
          className="flex items-center gap-3 group text-left"
        >
          {/* Custom Mountain Geometry Logo */}
          <div className="w-10 h-10 rounded-xl bg-[#12372A] border border-[#D4A853]/40 flex items-center justify-center shadow-inner group-hover:border-[#D4A853] transition-colors shrink-0">
            <svg
              className="w-6 h-6 text-[#D4A853]"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="m8 3 4 8 5-5 5 15H2L8 3z" />
              <path d="M4.14 15.08 9 10" stroke="#F7F5F0" opacity="0.6" />
            </svg>
          </div>

          <div className="flex flex-col">
            <span className="font-serif font-bold text-base sm:text-lg tracking-wider text-[#F7F5F0] leading-none group-hover:text-[#D4A853] transition-colors">
              MAHABALESHWAR WALA
            </span>
            <span className="text-[10px] sm:text-xs uppercase tracking-[0.25em] text-[#D4A853] font-semibold mt-1">
              Tours & Travels
            </span>
          </div>
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
          {navLinks.map((link) => {
            const isActive = currentPath === link.path;
            return (
              <a
                key={link.path}
                href={link.path}
                onClick={(e) => handleLinkClick(link.path, e)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium tracking-wide transition-all ${
                  isActive
                    ? "text-[#D4A853] bg-[#12372A]/80 font-semibold shadow-sm"
                    : "text-[#F7F5F0]/85 hover:text-[#F7F5F0] hover:bg-[#12372A]/40"
                }`}
              >
                {link.label}
              </a>
            );
          })}
        </nav>

        {/* Right CTA Actions */}
        <div className="hidden sm:flex items-center gap-3">
          <a
            href={`tel:${businessConfig.phoneRaw}`}
            className="flex items-center gap-2 text-xs text-[#F7F5F0] hover:text-[#D4A853] px-3 py-2 rounded-xl transition-colors font-medium border border-[#D4A853]/20 hover:border-[#D4A853]/50"
            title="Call Verified Phone"
          >
            <Phone className="w-3.5 h-3.5 text-[#D4A853]" />
            <span className="hidden xl:inline">{businessConfig.phone}</span>
            <span className="xl:hidden">Call Us</span>
          </a>

          <a
            href={buildGeneralWhatsAppUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-[#D4A853] hover:bg-[#C29541] text-[#071C14] px-4 py-2 rounded-xl font-semibold text-xs shadow-md hover:shadow-lg transition-all transform active:scale-95"
            title="Enquire on WhatsApp"
          >
            <MessageCircle className="w-3.5 h-3.5 text-[#071C14]" />
            <span>Book Now</span>
          </a>
        </div>

        {/* Mobile menu and Quick Book buttons */}
        <div className="flex sm:hidden items-center gap-2">
          <a
            href={buildGeneralWhatsAppUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 bg-[#D4A853] text-[#071C14] px-3 py-1.5 rounded-lg font-semibold text-xs"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Book</span>
          </a>

          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-[#F7F5F0] hover:bg-[#12372A] border border-[#D4A853]/20"
            aria-label="Toggle navigation menu"
            aria-expanded={mobileMenuOpen}
          >
            {mobileMenuOpen ? <X className="w-5 h-5 text-[#D4A853]" /> : <Menu className="w-5 h-5 text-[#F7F5F0]" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#071C14] border-t border-[#D4A853]/20 px-4 pt-3 pb-6 space-y-2 animate-in fade-in slide-in-from-top-2">
          <div className="grid grid-cols-2 gap-1.5 pb-3 border-b border-[#12372A]">
            {navLinks.map((link) => {
              const isActive = currentPath === link.path;
              return (
                <a
                  key={link.path}
                  href={link.path}
                  onClick={(e) => handleLinkClick(link.path, e)}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? "text-[#D4A853] bg-[#12372A] font-semibold"
                      : "text-[#F7F5F0]/80 hover:text-white hover:bg-[#12372A]/40"
                  }`}
                >
                  {link.label}
                </a>
              );
            })}
          </div>

          <div className="pt-2 space-y-2">
            <div className="flex items-center gap-2 text-xs text-[#F7F5F0]/70 py-1">
              <MapPin className="w-3.5 h-3.5 text-[#D4A853] shrink-0" />
              <span className="truncate">{businessConfig.addressShort}</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <a
                href={`tel:${businessConfig.phoneRaw}`}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl border border-[#D4A853]/40 text-[#F7F5F0] text-xs font-medium hover:bg-[#12372A]"
              >
                <Phone className="w-3.5 h-3.5 text-[#D4A853]" />
                <span>Call {businessConfig.phone}</span>
              </a>

              <a
                href={buildGeneralWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-[#25D366] text-white text-xs font-semibold shadow-md"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
