import React from "react";
import { Compass, PhoneCall, CalendarRange, Clock, Star, MapPin, CheckCircle } from "lucide-react";
import { whyChooseUsData } from "../data/whyChooseUs";

const iconMap: Record<string, React.ElementType> = {
  Compass,
  PhoneCall,
  CalendarRange,
  Clock,
  Star,
  MapPin
};

export const WhyChooseUs: React.FC = () => {
  return (
    <section className="py-16 sm:py-24 bg-[#0B2118] text-[#F7F5F0] border-t border-[#12372A]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#12372A] border border-[#D4A853]/30 text-[#D4A853] text-xs font-semibold uppercase tracking-wider mb-3">
            <CheckCircle className="w-3.5 h-3.5" />
            <span>Verified Local Travel Partner</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#F7F5F0] tracking-tight">
            Travel Mahabaleshwar With Confidence
          </h2>
          <p className="mt-3 text-base text-[#F7F5F0]/80 leading-relaxed">
            Authentic regional knowledge, direct coordination with local drivers, and clear communication from start to finish.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {whyChooseUsData.map((item) => {
            const Icon = iconMap[item.iconName] || Star;

            return (
              <div
                key={item.id}
                className="bg-[#071C14] rounded-2xl border border-[#12372A] p-6 sm:p-7 flex flex-col justify-between space-y-4 hover:border-[#D4A853]/40 transition-all duration-300"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-4">
                    <div className="w-12 h-12 rounded-xl bg-[#12372A] border border-[#D4A853]/30 flex items-center justify-center text-[#D4A853]">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-semibold text-[#D4A853] uppercase tracking-wider bg-[#12372A]/70 px-2.5 py-1 rounded-md">
                      {item.badge}
                    </span>
                  </div>

                  <h3 className="font-serif text-xl font-bold text-white">
                    {item.title}
                  </h3>
                  <p className="mt-2 text-xs sm:text-sm text-[#F7F5F0]/75 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
