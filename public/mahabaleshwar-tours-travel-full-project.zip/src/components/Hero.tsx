import React from "react";
import { Star, Phone, MessageCircle, ShieldCheck } from "lucide-react";
import { businessConfig } from "../data/businessConfig";
import { buildGeneralWhatsAppUrl } from "../utils/whatsapp";
import { BookingWidget } from "./BookingWidget";
import { Image } from "./Image";

export const Hero: React.FC = () => {
  return (
    <section className="relative min-h-[92vh] flex flex-col justify-between overflow-hidden bg-[#071C14]">
      {/* Background Image with Atmospheric Overlays */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <Image
          src="/assets/aistudio/kates-point.jpg"
          alt="Breathtaking panoramic view from Kate's Point overlooking Krishna valley in Mahabaleshwar"
          priority={true}
          containerClassName="w-full h-full absolute inset-0"
          className="w-full h-full object-cover object-center scale-105"
        />
        {/* Deep Green & Forest Vignettes */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#071C14] via-[#071C14]/80 to-[#071C14]/65" />
        <div className="absolute inset-0 bg-radial from-transparent via-[#071C14]/50 to-[#071C14]" />
      </div>

      {/* Main Hero Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 md:pt-16 pb-8 w-full flex-1 flex flex-col justify-center">
        <div className="max-w-3xl space-y-5 text-left">
          {/* Small Top Label */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#12372A]/80 border border-[#D4A853]/30 text-[#D4A853] text-[11px] sm:text-xs tracking-[0.2em] font-semibold uppercase backdrop-blur-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-[#D4A853]" />
            MAHABALESHWAR • PANCHGANI • WESTERN GHATS
          </div>

          {/* Main Headline */}
          <h1 className="font-serif text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-[#F7F5F0] tracking-tight leading-[1.1]">
            Explore Mahabaleshwar. <br />
            <span className="text-[#D4A853] italic font-normal">Travel Your Way.</span>
          </h1>

          {/* Supporting Line */}
          <p className="text-base sm:text-lg md:text-xl text-[#F7F5F0]/90 leading-relaxed font-normal max-w-2xl">
            {businessConfig.supportingLine}
          </p>

          {/* Social Proof Strip (Strictly Verified Only) */}
          <div className="flex flex-wrap items-center gap-3 pt-1">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-[#0B2118]/90 border border-[#D4A853]/25 text-xs text-white">
              <div className="flex text-[#D4A853]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-[#D4A853] text-[#D4A853]" />
                ))}
              </div>
              <span className="font-bold text-[#D4A853]">5.0</span>
              <span className="text-white/40">•</span>
              <span className="text-white/80 font-medium">13 Google Reviews</span>
            </div>

            <div className="inline-flex items-center gap-1.5 text-xs text-white/80 bg-[#12372A]/70 px-3 py-1.5 rounded-xl border border-white/10">
              <ShieldCheck className="w-3.5 h-3.5 text-[#25D366]" />
              <span>Verified Local Business</span>
            </div>
          </div>

          {/* Primary & Secondary Call to Action Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 pt-2">
            <a
              href={buildGeneralWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2.5 bg-[#D4A853] hover:bg-[#C29541] text-[#071C14] font-bold text-sm tracking-wide px-7 py-3.5 rounded-xl shadow-xl hover:shadow-2xl transition-all transform active:scale-95"
            >
              <MessageCircle className="w-4 h-4 text-[#071C14]" />
              <span>Book on WhatsApp</span>
            </a>

            <a
              href={`tel:${businessConfig.phoneRaw}`}
              className="inline-flex items-center justify-center gap-2.5 bg-[#12372A]/80 hover:bg-[#12372A] text-white border border-[#D4A853]/30 hover:border-[#D4A853] font-medium text-sm px-6 py-3.5 rounded-xl backdrop-blur-sm transition-all"
            >
              <Phone className="w-4 h-4 text-[#D4A853]" />
              <span>Call {businessConfig.phone}</span>
            </a>
          </div>
        </div>

        {/* Floating Hero Booking Card */}
        <div className="mt-8 md:mt-12 w-full">
          <BookingWidget />
        </div>
      </div>
    </section>
  );
};
