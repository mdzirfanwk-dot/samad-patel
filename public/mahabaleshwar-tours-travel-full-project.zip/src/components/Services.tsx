import React from "react";
import { Compass, Mountain, Shield, Waves, Plane, Navigation, ArrowRight, MessageCircle } from "lucide-react";
import { servicesData, ServiceItem } from "../data/services";
import { buildWhatsAppUrl } from "../utils/whatsapp";
import { Image } from "./Image";

const iconMap: Record<string, React.ElementType> = {
  Compass,
  Mountain,
  Shield,
  Waves,
  Plane,
  Navigation
};

interface ServicesProps {
  onSelectService?: (service: ServiceItem) => void;
}

export const Services: React.FC<ServicesProps> = () => {
  const handleServiceEnquire = (service: ServiceItem) => {
    const message = `Hello Mahabaleshwar wala Tours and Travel,
I would like to enquire about your "${service.title}" service.
Pickup Location: Mahabaleshwar / Hotel
Travel Date: To be confirmed
Please share current vehicle options and availability details.
Thank you.`;
    window.open(buildWhatsAppUrl(message), "_blank", "noopener,noreferrer");
  };

  return (
    <section id="services" className="py-16 sm:py-24 bg-[#F7F5F0]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-2xl text-left mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#12372A]/10 text-[#12372A] text-xs font-bold uppercase tracking-wider mb-3">
            <span>Tailored Mountain Travel</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#071C14] tracking-tight">
            Travel Services Made Simple
          </h2>
          <p className="mt-3 text-base text-[#6B7280] leading-relaxed">
            From local sightseeing to longer journeys, plan your travel around Mahabaleshwar with ease.
          </p>

          <div className="mt-3 inline-block text-[11px] font-medium text-[#12372A] bg-[#D4A853]/20 border border-[#D4A853]/40 px-3 py-1 rounded-md">
            Services Available — Please Confirm Availability
          </div>
        </div>

        {/* 6 Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {servicesData.map((service) => {
            const IconComponent = iconMap[service.iconName] || Compass;

            return (
              <div
                key={service.id}
                className="group bg-white rounded-2xl border border-[#12372A]/10 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden hover:-translate-y-1"
              >
                {/* Image & Overlay */}
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={service.image}
                    alt={service.title}
                    containerClassName="w-full h-full absolute inset-0"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#071C14]/80 via-[#071C14]/20 to-transparent z-10 pointer-events-none" />
                  
                  {/* Badge */}
                  {service.badge && (
                    <span className="absolute top-3 right-3 px-2.5 py-1 bg-[#12372A]/90 backdrop-blur-sm text-[#D4A853] text-[10px] font-semibold uppercase tracking-wider rounded-md border border-[#D4A853]/30">
                      {service.badge}
                    </span>
                  )}

                  {/* Icon */}
                  <div className="absolute bottom-3 left-4 w-10 h-10 rounded-xl bg-[#D4A853] text-[#071C14] flex items-center justify-center shadow-md">
                    <IconComponent className="w-5 h-5" />
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    <h3 className="font-serif text-xl font-bold text-[#071C14] group-hover:text-[#12372A] transition-colors">
                      {service.title}
                    </h3>
                    <p className="mt-2 text-xs sm:text-sm text-[#6B7280] leading-relaxed">
                      {service.description}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-[#12372A]/5 flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-[#12372A]/70 uppercase tracking-wider">
                      Enquire for Availability
                    </span>

                    <button
                      type="button"
                      onClick={() => handleServiceEnquire(service)}
                      className="inline-flex items-center gap-1.5 text-xs font-bold text-[#12372A] hover:text-[#D4A853] group-hover:translate-x-0.5 transition-all cursor-pointer"
                    >
                      <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
                      <span>Enquire</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
