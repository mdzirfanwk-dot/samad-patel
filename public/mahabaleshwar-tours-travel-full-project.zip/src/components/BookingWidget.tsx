import React, { useState, useEffect } from "react";
import { Calendar, MapPin, Users, Navigation, MessageCircle, Sparkles } from "lucide-react";
import { buildBookingEnquiryUrl } from "../utils/whatsapp";

interface BookingWidgetProps {
  className?: string;
  variant?: "floating" | "compact" | "contained";
  initialDestination?: string;
  initialTravelType?: string;
}

export const BookingWidget: React.FC<BookingWidgetProps> = ({
  className = "",
  variant = "floating",
  initialDestination = "Mahabaleshwar",
  initialTravelType = "Local Sightseeing"
}) => {
  const [pickup, setPickup] = useState("");
  const [destination, setDestination] = useState(initialDestination);
  const [travelDate, setTravelDate] = useState("");
  const [passengers, setPassengers] = useState("2");
  const [travelType, setTravelType] = useState(initialTravelType);

  useEffect(() => {
    if (initialDestination) {
      setDestination(initialDestination);
    }
  }, [initialDestination]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const url = buildBookingEnquiryUrl({
      pickup: pickup.trim() || "Mahabaleshwar / Hotel / Resort",
      destination,
      travelDate: travelDate || "Today / Flexible",
      passengers,
      travelType
    });
    window.open(url, "_blank", "noopener,noreferrer");
  };

  return (
    <div
      className={`bg-[#071C14]/90 backdrop-blur-md text-[#F7F5F0] rounded-2xl border border-[#D4A853]/30 shadow-2xl p-5 md:p-6 transition-all ${className}`}
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 mb-4 border-b border-[#12372A]">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[#D4A853]/15 flex items-center justify-center text-[#D4A853]">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-serif font-bold text-base sm:text-lg text-white">
              Plan Your Mahabaleshwar Journey
            </h3>
            <p className="text-xs text-[#D4A853]">
              Direct quote via WhatsApp • No hidden charges
            </p>
          </div>
        </div>
        <span className="text-[11px] font-medium text-white/70 bg-[#12372A] px-2.5 py-1 rounded-full self-start sm:self-auto">
          Fast WhatsApp Response
        </span>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Pickup Location */}
          <div className="space-y-1 sm:col-span-2 lg:col-span-1">
            <label className="block text-[11px] uppercase tracking-wider font-semibold text-[#D4A853]">
              Pickup Location
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-[#D4A853] absolute left-3 top-3 pointer-events-none" />
              <input
                type="text"
                value={pickup}
                onChange={(e) => setPickup(e.target.value)}
                placeholder="Mahabaleshwar / Hotel / Resort"
                className="w-full pl-9 pr-3 py-2.5 bg-[#0B2118] border border-[#12372A] rounded-xl text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#D4A853] focus:ring-1 focus:ring-[#D4A853] transition-all"
              />
            </div>
          </div>

          {/* Destination */}
          <div className="space-y-1">
            <label className="block text-[11px] uppercase tracking-wider font-semibold text-[#D4A853]">
              Destination
            </label>
            <div className="relative">
              <Navigation className="w-4 h-4 text-[#D4A853] absolute left-3 top-3 pointer-events-none" />
              <select
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 bg-[#0B2118] border border-[#12372A] rounded-xl text-xs text-white focus:outline-none focus:border-[#D4A853] focus:ring-1 focus:ring-[#D4A853] transition-all appearance-none cursor-pointer"
              >
                <option value="Mahabaleshwar" className="bg-[#071C14]">Mahabaleshwar Sightseeing</option>
                <option value="Panchgani" className="bg-[#071C14]">Panchgani Tour</option>
                <option value="Pratapgad" className="bg-[#071C14]">Pratapgad Fort</option>
                <option value="Tapola" className="bg-[#071C14]">Tapola Lakeside</option>
                <option value="Other / Custom" className="bg-[#071C14]">Other / Custom Route</option>
              </select>
            </div>
          </div>

          {/* Travel Date */}
          <div className="space-y-1">
            <label className="block text-[11px] uppercase tracking-wider font-semibold text-[#D4A853]">
              Travel Date
            </label>
            <div className="relative">
              <Calendar className="w-4 h-4 text-[#D4A853] absolute left-3 top-3 pointer-events-none" />
              <input
                type="date"
                value={travelDate}
                onChange={(e) => setTravelDate(e.target.value)}
                min={new Date().toISOString().split("T")[0]}
                className="w-full pl-9 pr-3 py-2.5 bg-[#0B2118] border border-[#12372A] rounded-xl text-xs text-white focus:outline-none focus:border-[#D4A853] focus:ring-1 focus:ring-[#D4A853] transition-all cursor-pointer"
              />
            </div>
          </div>

          {/* Passengers */}
          <div className="space-y-1">
            <label className="block text-[11px] uppercase tracking-wider font-semibold text-[#D4A853]">
              Passengers
            </label>
            <div className="relative">
              <Users className="w-4 h-4 text-[#D4A853] absolute left-3 top-3 pointer-events-none" />
              <select
                value={passengers}
                onChange={(e) => setPassengers(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 bg-[#0B2118] border border-[#12372A] rounded-xl text-xs text-white focus:outline-none focus:border-[#D4A853] focus:ring-1 focus:ring-[#D4A853] transition-all appearance-none cursor-pointer"
              >
                <option value="1" className="bg-[#071C14]">1 Person</option>
                <option value="2" className="bg-[#071C14]">2 People (Couple)</option>
                <option value="3" className="bg-[#071C14]">3 People</option>
                <option value="4" className="bg-[#071C14]">4 People (Small Family)</option>
                <option value="5" className="bg-[#071C14]">5 People</option>
                <option value="6" className="bg-[#071C14]">6 People (Family/SUV)</option>
                <option value="7" className="bg-[#071C14]">7 People</option>
                <option value="8+" className="bg-[#071C14]">8+ (Group / Tempo)</option>
              </select>
            </div>
          </div>

          {/* Travel Type */}
          <div className="space-y-1 sm:col-span-2 lg:col-span-1">
            <label className="block text-[11px] uppercase tracking-wider font-semibold text-[#D4A853]">
              Travel Type
            </label>
            <select
              value={travelType}
              onChange={(e) => setTravelType(e.target.value)}
              className="w-full px-3 py-2.5 bg-[#0B2118] border border-[#12372A] rounded-xl text-xs text-white focus:outline-none focus:border-[#D4A853] focus:ring-1 focus:ring-[#D4A853] transition-all appearance-none cursor-pointer"
            >
              <option value="Local Sightseeing" className="bg-[#071C14]">Local Sightseeing</option>
              <option value="One Way" className="bg-[#071C14]">One Way Transfer</option>
              <option value="Round Trip" className="bg-[#071C14]">Round Trip</option>
              <option value="Airport Transfer" className="bg-[#071C14]">Airport Transfer</option>
              <option value="Outstation" className="bg-[#071C14]">Outstation Travel</option>
              <option value="Custom Tour" className="bg-[#071C14]">Custom Tour</option>
            </select>
          </div>
        </div>

        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[11px] text-white/60 text-center sm:text-left">
            *Pricing and vehicle options are shared directly on WhatsApp based on actual route &amp; date.
          </p>

          <button
            type="submit"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#D4A853] hover:bg-[#C29541] text-[#071C14] font-bold text-xs uppercase tracking-wider py-3 px-6 rounded-xl shadow-lg hover:shadow-xl transition-all cursor-pointer transform active:scale-95 shrink-0"
          >
            <MessageCircle className="w-4 h-4 text-[#071C14]" />
            <span>Get a Quote on WhatsApp</span>
          </button>
        </div>
      </form>
    </div>
  );
};
